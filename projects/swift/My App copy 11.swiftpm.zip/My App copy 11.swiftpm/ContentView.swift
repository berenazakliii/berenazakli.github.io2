import SwiftUI

struct ContentView: View {
    @State private var num1 = ""
    @State private var num2 = ""
    @State private var result = ""
    
    func addNumbers() {
        let first = Double(num1) ?? 0
        let second = Double(num2) ?? 0
        result = String(first + second)
    }
    func subtractNumbers() {
        let first = Double(num1) ?? 0
        let second = Double(num2) ?? 0
        result = String(first - second)
        
        }
    func bolmek() {
        let first = Double(num1) ?? 0
        let second = Double(num2) ?? 0
        result = String(first/second)
        
    }
    func carpmak() {
        let first = Double(num1) ?? 0
        let second = Double(num2) ?? 0
        result = String(first*second)
        
    }
    
    
    
    var body: some View {
        VStack(spacing: 25) {
            Text("HESAP MAKİNESİ")
                .font(.title)
                .bold()
            TextField("First number:", text: $num1)
                .keyboardType(.decimalPad)
            TextField("Second number:", text: $num2)
                .keyboardType(.decimalPad)
        
            Button(action: addNumbers) {
                Text("Add")
            }
            Button(action: subtractNumbers) {
                Text("subtract")
            }
            
            Button(action: bolmek) {
                Text("division")
            }
            Button(action: carpmak) {
                Text("multiplication")
            }
            
            Text("Result: \(result)")
        }
        .padding()
    }


}
